/*
 This class defines a custom rounded JButton with hover effects,
 dynamic background color changes, and a polished appearance using anti-aliasing.
 */

package designfinale;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RoundedButton extends JButton {

    // Default background color of the button
    private Color defaultColor;

    // Background color when the mouse hovers over the button
    private Color hoverColor;

    // Background color when the button is disabled
    private Color disabledColor = Color.DARK_GRAY;

    
    public RoundedButton(String text, Color defaultColor, Color hoverColor) {
        super(text);
        this.defaultColor = defaultColor;
        this.hoverColor = hoverColor;

        // Customize the button appearance
        setContentAreaFilled(false); // Don't fill background with default Look & Feel
        setFocusPainted(false);      // Remove focus ring
        setBorderPainted(false);     // Hide border
        setBackground(defaultColor); // Set initial background color
        setForeground(Color.WHITE);  // Set text color

        // Add hover effect only if the button is enabled
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(hoverColor);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(defaultColor);
                }
            }
        });
    }

    
    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        setBackground(enabled ? defaultColor : disabledColor);
    }

    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        // Enable smooth edges
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Fill rounded rectangle with the current background color
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);

        // Let the superclass paint the text and icon
        super.paintComponent(g);
    }

    
    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        // Enable smooth edges
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw rounded border in the same color as background
        g2.setColor(getBackground());
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
    }

   
    public void setDisabledColor(Color color) {
        this.disabledColor = color;

        // If currently disabled, apply the new color immediately
        if (!isEnabled()) {
            setBackground(disabledColor);
        }
    }
}
