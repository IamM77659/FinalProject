/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package designfinale;

/**
 *
 * @author Students Account
 *
 *
 */
import java.awt.Event;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import designfinale.log_in.name;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Component;
import java.awt.Color;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JTable;

public class Home extends javax.swing.JFrame {

    private static String getTitle, getcode;
    private static final String accfiles = "src\\designfinale\\accounts.json";
    private static final String filepath = "src\\designfinale\\events.json";
    private static JSONParser jsonParser = new JSONParser();
    private static JSONObject use = new JSONObject();
    private static JSONArray acclist = new JSONArray();
    private static JSONObject accobj = new JSONObject();
    private static JSONArray list = new JSONArray();
    private static JSONObject record = new JSONObject();
    private static JSONArray attendanceArray = new JSONArray();
    private final DefaultTableModel tablemodel;
    private static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); //date formatter
    private static DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");// time formatter

    /**
     * Creates new form Attendee
     */
    public class searchp {

        public static String box;

    }

    public Home() {
        initComponents();
        setResizable(false);
        LBLShowUser.setText(name.uname + "!"); // sets username on the display
        tablemodel = new DefaultTableModel(new String[]{"Title", "Date", "Start", "End"}, 0); // formats the table
        table.setModel(tablemodel);
        Joinbtn.setEnabled(false);
        table.setRowHeight(30);
        setLocationRelativeTo(null);

        // Adds a listener to monitor any changes in the text of codeField
        codeField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {

            // This method is called when text is inserted into the text field
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                checkInput(); // Check if the input is not empty, then enable the button
            }

            // This method is called when text is removed from the text field
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                checkInput(); // Re-check if the input is now empty, and disable the button if needed
            }

            // This method is called when there's a change in text formatting (rarely used with plain text fields)
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                checkInput(); // Still good to have for completeness
            }

            // This method checks if the codeField has any non-space text
            private void checkInput() {
                String input = codeField.getText().trim(); // Get text and remove spaces from both ends
                Joinbtn.setEnabled(!input.isEmpty());   // Enable the search button only if input is not empty
            }
        });
        // makes the listed objects on the table red when it is set in the future
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {

                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                String dateStr = (String) table.getValueAt(row, 1); // Column index 1 = date
                String timeStr = (String) table.getValueAt(row, 2); // Column index 2 = startTime

                if (dateStr != null && timeStr != null) {
                    try {
                        LocalDate eventDate = LocalDate.parse(dateStr, dateFormatter);
                        LocalTime eventTime = LocalTime.parse(timeStr, timeFormatter);
                        LocalDateTime eventDateTime = LocalDateTime.of(eventDate, eventTime);
                        LocalDateTime now = LocalDateTime.now();

                        if (eventDateTime.isAfter(now)) {
                            c.setForeground(Color.RED);
                        } else {
                            c.setForeground(isSelected ? table.getSelectionForeground() : Color.BLACK);
                        }
                    } catch (Exception ex) {
                        // fallback if parsing fails
                        c.setForeground(Color.BLACK);
                    }
                } else {
                    c.setForeground(Color.BLACK);
                }

                return c;
            }
        });

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        codeField = new javax.swing.JTextField();
        Joinbtn = Joinbtn = new designfinale.RoundedButton("Search", new Color(13, 48, 140), new Color(102, 153, 255));
        LBLShowUser = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        JoinBTN2 = JoinBTN2 = new designfinale.RoundedButton("Search", new Color(13,48,140), new Color(102, 153, 255));
        ;
        SearchEvent = new javax.swing.JTextField();
        SearchBTn = SearchBTn = new designfinale.RoundedButton("Search", new Color(13,48,140), new Color(102, 153, 255));
        ;
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Event Attendance System");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AttendWise");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title", "Date", "Start", "End"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.setGridColor(new java.awt.Color(0, 0, 0));
        table.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tableFocusLost(evt);
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 730, 440));

        jPanel3.setBackground(new java.awt.Color(51, 102, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        codeField.setBackground(new java.awt.Color(51, 102, 255));
        codeField.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        codeField.setForeground(new java.awt.Color(255, 255, 255));
        codeField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        codeField.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Enter Event Code", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N
        codeField.setCaretColor(new java.awt.Color(255, 255, 255));
        codeField.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                codeFieldInputMethodTextChanged(evt);
            }
        });
        codeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codeFieldActionPerformed(evt);
            }
        });
        jPanel3.add(codeField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 270, 110));

        Joinbtn.setBackground(new java.awt.Color(13, 48, 140));
        Joinbtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Joinbtn.setText("Join Event");
        Joinbtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Joinbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JoinbtnActionPerformed(evt);
            }
        });
        jPanel3.add(Joinbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 250, 40));

        LBLShowUser.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        LBLShowUser.setForeground(new java.awt.Color(255, 255, 255));
        LBLShowUser.setText("Temp");
        jPanel3.add(LBLShowUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Welcome,");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 630));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Events");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 20, -1, -1));

        JoinBTN2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JoinBTN2.setText("Join Event");
        JoinBTN2.setEnabled(false);
        JoinBTN2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                JoinBTN2FocusGained(evt);
            }
        });
        JoinBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JoinBTN2ActionPerformed(evt);
            }
        });
        jPanel1.add(JoinBTN2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 550, 230, 40));

        SearchEvent.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        SearchEvent.setForeground(new java.awt.Color(0, 0, 0));
        SearchEvent.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search by TItle", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(0, 0, 0))); // NOI18N
        SearchEvent.setCaretColor(new java.awt.Color(0, 0, 0));
        SearchEvent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchEventActionPerformed(evt);
            }
        });
        jPanel1.add(SearchEvent, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 330, 50));

        SearchBTn.setBackground(new java.awt.Color(13, 48, 140));
        SearchBTn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        SearchBTn.setForeground(new java.awt.Color(255, 255, 255));
        SearchBTn.setText("Search");
        SearchBTn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBTnActionPerformed(evt);
            }
        });
        jPanel1.add(SearchBTn, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 20, 80, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 610));

        jMenuBar1.setForeground(new java.awt.Color(255, 255, 255));
        jMenuBar1.setOpaque(true);

        jMenu2.setText("Navigate");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, 0));
        jMenuItem1.setText("View Profile");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem1);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed

        new Profile().setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void SearchEventActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchEventActionPerformed
        searchByEnter(); // searches events by pressing enter
    }//GEN-LAST:event_SearchEventActionPerformed

    private void SearchBTnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBTnActionPerformed
        search(); //search for events

    }//GEN-LAST:event_SearchBTnActionPerformed

    private void JoinbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JoinbtnActionPerformed
        joinBypressingButton(); // attempts to join the user by pressing the join button

    }//GEN-LAST:event_JoinbtnActionPerformed

    private void codeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codeFieldActionPerformed
        joinByPressingEnter(); // attemps to join the attendee by pressing enter

    }//GEN-LAST:event_codeFieldActionPerformed

    private void codeFieldInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_codeFieldInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_codeFieldInputMethodTextChanged

    private void JoinBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JoinBTN2ActionPerformed

        joinByTitle(); // join by title method

    }//GEN-LAST:event_JoinBTN2ActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        JoinBTN2.setEnabled(true);
    }//GEN-LAST:event_tableMouseClicked

    private void tableFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tableFocusLost

    }//GEN-LAST:event_tableFocusLost

    private void JoinBTN2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_JoinBTN2FocusGained

    }//GEN-LAST:event_JoinBTN2FocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set system look and feel */

        try {
            // Use the default cross-platform look and feel
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(log_in.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    public static void save() throws IOException {
        try {
            FileWriter file = new FileWriter(filepath);
            file.write(record.toJSONString());
            file.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occured. " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    public static void filecheck() throws FileNotFoundException, IOException, ParseException {

        // Create a FileReader to read the file specified by 'filepath'
        FileReader reader = new FileReader(filepath);

        // Check if the file is ready to be read 
        if (reader.ready()) {
            Scanner s = new Scanner(reader);
            String line = "";

            // Read the file line by line and store it in 'line' variable
            while (s.hasNext()) {
                line = line + s.nextLine();
            }

            // If the file is not empty, parse its contents
            if (!line.equals("")) {
                reader.close();

                // Create a new FileReader to read and parse JSON data
                FileReader reader2 = new FileReader(filepath);
                record = (JSONObject) jsonParser.parse(reader2);
                list = (JSONArray) record.get("events");
                reader2.close();
            }
        }
    }

    public static void accfilecheck() throws FileNotFoundException, IOException, ParseException {

        // Create a FileReader to read the file specified by 'filepath'
        FileReader reader = new FileReader(accfiles);

        // Check if the file is ready to be read 
        if (reader.ready()) {
            Scanner s = new Scanner(reader);
            String line = "";

            // Read the file line by line and store it in 'line' variable
            while (s.hasNext()) {
                line = line + s.nextLine();
            }

            // If the file is not empty, parse its contents
            if (!line.equals("")) {
                reader.close();

                // Create a new FileReader to read and parse JSON data
                FileReader reader2 = new FileReader(accfiles);
                accobj = (JSONObject) jsonParser.parse(reader2);
                acclist = (JSONArray) accobj.get("accounts");
                reader2.close();
            }
        }
    }

    //join an event by pressing a button that triggers this method
    private void joinByTitle() {
        int selrow = table.getSelectedRow();

        // Ensure the user has selected an event in the table
        if (selrow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select an event first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Retrieve the selected event's title
            String selectedTitle = table.getValueAt(selrow, 0).toString();

            // Load events and accounts from storage
            filecheck();
            accfilecheck();

            // Check if the user is already attending a different event
            for (Object obj : list) {
                JSONObject event = (JSONObject) obj;
                JSONArray attendance = (JSONArray) event.getOrDefault("attendance", new JSONArray());

                for (Object entry : attendance) {
                    if (entry instanceof JSONObject attendee && name.uname.equals(attendee.get("username"))) {
                        String currentTitle = (String) event.get("title");

                        // If already attending a different event, prevent joining
                        if (!currentTitle.equals(selectedTitle)) {
                            JOptionPane.showMessageDialog(this,
                                    "You are already attending another event (" + currentTitle + "). You can only join one event at a time.",
                                    "Already Attending",
                                    JOptionPane.WARNING_MESSAGE);
                            return;
                        }
                    }
                }
            }

            // Search for the selected event in the list
            for (int i = 0; i < list.size(); i++) {
                JSONObject event = (JSONObject) list.get(i);
                String eventTitle = (String) event.get("title");

                if (!selectedTitle.equals(eventTitle)) {
                    continue;
                }

                // Extract host and event timing information
                String host = (String) event.get("created by");
                String dateStr = (String) event.get("date");
                String startTimeStr = (String) event.get("startTime");
                String endTimeStr = (String) event.get("endTime");

                DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");

                LocalDate eventDate = LocalDate.parse(dateStr, dateFormatter);
                LocalTime eventStartTime = LocalTime.parse(startTimeStr, timeFormatter);
                LocalTime eventEndTime = LocalTime.parse(endTimeStr, timeFormatter);

                LocalDateTime eventStart = LocalDateTime.of(eventDate, eventStartTime);
                LocalDateTime eventEnd = LocalDateTime.of(eventDate, eventEndTime);
                LocalDateTime now = LocalDateTime.now();

                // Prevent the event host from joining their own event
                if (name.uname.equals(host)) {
                    JOptionPane.showMessageDialog(this,
                            "You cannot join your own event.",
                            "Access Denied",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Prevent joining an event that hasn't started yet
                if (now.isBefore(eventStart)) {
                    JOptionPane.showMessageDialog(this,
                            "You cannot join a future event.",
                            "Access Denied",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Prevent joining an event that already ended
                if (now.isAfter(eventEnd)) {
                    JOptionPane.showMessageDialog(this,
                            "This event has already ended. You cannot join.",
                            "Event Over",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                JSONArray attendanceArray = (JSONArray) event.getOrDefault("attendance", new JSONArray());

                // Check if the user already joined this event
                for (Object obj : attendanceArray) {
                    if (obj instanceof JSONObject attendee && name.uname.equals(attendee.get("username"))) {
                        JOptionPane.showMessageDialog(this,
                                "You have already joined this event.",
                                "Already Joined",
                                JOptionPane.INFORMATION_MESSAGE);
                        return;
                    }
                }

                // If event has a code, validate it
                String code = (String) event.get("code");
                if (code != null && !code.isEmpty()) {
                    String input = JOptionPane.showInputDialog(this, "Please enter the event code:");
                    if (input == null || !input.equals(code)) {
                        JOptionPane.showMessageDialog(this,
                                "Incorrect or cancelled code input.",
                                "Access Denied",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Determine if the user is late based on the late limit
                boolean isLate = false;
                if (event.containsKey("lateMinutes")) {
                    try {
                        int lateLimit = Integer.parseInt(event.get("lateMinutes").toString());
                        LocalDateTime lateThreshold = eventStart.plusMinutes(lateLimit);
                        if (now.isAfter(lateThreshold)) {
                            isLate = true;
                        }
                    } catch (Exception e) {
                        // Ignore errors in lateMinutes parsing
                    }
                }

                // Record user's attendance
                LocalTime nowTime = LocalTime.now();
                String timeIn = nowTime.format(timeFormatter);

                JSONObject newAttendee = new JSONObject();
                newAttendee.put("username", name.uname);
                newAttendee.put("time in", timeIn);
                newAttendee.put("time out", "");
                newAttendee.put("status", isLate ? "Late" : "On Time");

                attendanceArray.add(newAttendee);
                event.put("attendance", attendanceArray);
                list.set(i, event);

                // Save updated event list
                save();

                // Show confirmation to the user
                JOptionPane.showMessageDialog(this,
                        isLate ? "You joined, but you are marked as LATE." : "Your attendance has been recorded.",
                        isLate ? "Late!" : "Success",
                        JOptionPane.INFORMATION_MESSAGE);

                // Open Participant Dashboard for the joined event
                ParticipantDashboard pd = new ParticipantDashboard(selectedTitle);
                pd.setEventTitle(selectedTitle);
                pd.setVisible(true);
                this.dispose(); // Close the current window
                return;
            }

            // If no event matched the selected title
            JOptionPane.showMessageDialog(this,
                    "Selected event not found.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);

        } catch (IOException | ParseException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this,
                    "An error occurred while joining the event.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void joinByPressingEnter() {
        int enter = Event.ENTER;
        if (enter == 10) { // 10 is the key code for Enter
            try {
                getcode = codeField.getText(); // Get the entered code
                filecheck(); // Load events JSON

                if (getcode.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Please Enter Something.", "Empty Code", HEIGHT);
                    return;
                }

                accfilecheck(); // Load accounts JSON
                String username = name.uname;

                // Check if user is already attending another event without timeout
                for (Object o : list) {
                    JSONObject evt = (JSONObject) o;
                    JSONArray attendanceArray = (JSONArray) evt.get("attendance");
                    if (attendanceArray != null) {
                        for (Object a : attendanceArray) {
                            if (a instanceof JSONObject) {
                                JSONObject att = (JSONObject) a;
                                if (username.equals(att.get("username")) && att.get("time out").toString().isEmpty()) {
                                    JOptionPane.showMessageDialog(rootPane,
                                            "You are already attending another event.\nYou can only join one event at a time.",
                                            "Already Attending", JOptionPane.WARNING_MESSAGE);
                                    return;
                                }
                            }
                        }
                    }
                }

                int matchfound = 0;

                // Iterate through all events to find a matching code
                for (int i = 0; i < list.size(); i++) {
                    JSONObject event = (JSONObject) list.get(i);
                    String code = (String) event.get("code");

                    if (getcode.equals(code)) {
                        String host = (String) event.get("created by");

                        // Prevent user from joining their own event
                        if (host.equals(username)) {
                            JOptionPane.showMessageDialog(rootPane, "You cannot join your own event.", "Access Denied", JOptionPane.WARNING_MESSAGE);
                            return;
                        }

                        // Extract date and time values from event
                        String eventDateStr = (String) event.get("date");
                        String startTimeStr = (String) event.get("startTime");
                        String endTimeStr = (String) event.get("endTime");

                        LocalDate eventDate = LocalDate.parse(eventDateStr, dateFormatter);
                        LocalTime startTime = LocalTime.parse(startTimeStr, timeFormatter);
                        LocalTime endTime = LocalTime.parse(endTimeStr, timeFormatter);

                        LocalDate currentDate = LocalDate.now();
                        LocalTime currentTime = LocalTime.now();

                        // Validate if the event has started or ended
                        if (currentDate.isBefore(eventDate) || (currentDate.equals(eventDate) && currentTime.isBefore(startTime))) {
                            JOptionPane.showMessageDialog(rootPane, "This event hasn't started yet.", "Too Early", JOptionPane.WARNING_MESSAGE);
                            return;
                        }

                        if (currentDate.isAfter(eventDate) || (currentDate.equals(eventDate) && currentTime.isAfter(endTime))) {
                            JOptionPane.showMessageDialog(rootPane, "This event has already ended.", "Too Late", JOptionPane.WARNING_MESSAGE);
                            return;
                        }

                        // Initialize attendance array if not present
                        JSONArray attendanceArray;
                        if (event.containsKey("attendance")) {
                            attendanceArray = (JSONArray) event.get("attendance");
                        } else {
                            attendanceArray = new JSONArray();
                        }

                        // Prevent duplicate attendance entries
                        for (Object o : attendanceArray) {
                            if (o instanceof JSONObject obj && username.equals(obj.get("username"))) {
                                JOptionPane.showMessageDialog(rootPane, "You have already been marked as attended.", "Already Recorded", HEIGHT);
                                return;
                            }
                        }

                        // Get current time in 12-hour format for display
                        LocalTime now = LocalTime.now();
                        DateTimeFormatter formatter12hr = DateTimeFormatter.ofPattern("hh:mm a");
                        String formattedTime = now.format(formatter12hr);

                        // Create attendance object
                        JSONObject attendeeObj = new JSONObject();
                        attendeeObj.put("username", username);
                        attendeeObj.put("time in", formattedTime);
                        attendeeObj.put("time out", "");

                        // Determine late status
                        boolean isLate = false;
                        if (event.containsKey("lateMinutes") && event.get("lateMinutes") != null) {
                            try {
                                int lateLimit = Integer.parseInt(event.get("lateMinutes").toString());
                                LocalTime lateThreshold = startTime.plusMinutes(lateLimit);
                                if (currentTime.isAfter(lateThreshold)) {
                                    isLate = true;
                                }
                            } catch (Exception e) {
                                // Ignore parsing errors for lateMinutes
                            }
                        }

                        // Set attendance status
                        attendeeObj.put("status", isLate ? "Late" : "On Time");

                        // Save updated attendance array
                        attendanceArray.add(attendeeObj);
                        event.put("attendance", attendanceArray);
                        list.set(i, event);
                        save(); // Save changes to file

                        // Notify user
                        JOptionPane.showMessageDialog(rootPane,
                                isLate ? "You have been marked as LATE.\nYour attendance is still recorded." : "Your attendance is noted by the host.",
                                isLate ? "Late Attendance" : "Event Successfully Attended",
                                isLate ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE);

                        // Open participant dashboard
                        String selectedTitle = (String) event.get("title");
                        ParticipantDashboard pd = new ParticipantDashboard(selectedTitle);
                        pd.setEventTitle(selectedTitle);
                        pd.setVisible(true);
                        this.dispose();
                        matchfound++;
                        break;
                    }
                }

                // If no matching code was found
                if (matchfound == 0) {
                    JOptionPane.showMessageDialog(rootPane, "Please check the code and try again.", "Code renewed or doesn't exist", JOptionPane.ERROR_MESSAGE);
                }

            } catch (IOException | ParseException ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }

            // Clear code input field
            codeField.setText("");
        }
    }

    private void joinBypressingButton() {
        try {
            // Retrieve and trim the event code entered by the user
            getcode = codeField.getText().trim();

            // Load the latest event and account JSON files
            filecheck();
            accfilecheck();

            // Show warning if no code is entered
            if (getcode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a code.", "Empty Field", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int matchfound = 0; // Tracks if a matching event is found
            LocalDateTime now = LocalDateTime.now(); // Capture the current date and time

            // Prevent user from joining multiple events simultaneously
            for (Object obj : list) {
                JSONObject event = (JSONObject) obj;
                JSONArray attendance = (JSONArray) event.getOrDefault("attendance", new JSONArray());

                for (Object entry : attendance) {
                    if (entry instanceof JSONObject attendee && name.uname.equals(attendee.get("username"))) {
                        String currentTitle = (String) event.get("title");
                        String eventCode = (String) event.get("code");

                        if (!getcode.equals(eventCode)) {
                            JOptionPane.showMessageDialog(this,
                                    "You are already attending another event (" + currentTitle + ").",
                                    "Already Attending",
                                    JOptionPane.WARNING_MESSAGE);
                            return;
                        }
                    }
                }
            }

            // Search for the event that matches the entered code
            for (int i = 0; i < list.size(); i++) {
                JSONObject event = (JSONObject) list.get(i);
                String code = (String) event.get("code");

                if (!getcode.equals(code)) {
                    continue;
                }

                String host = (String) event.get("created by");

                // Prevent users from joining their own events
                if (host.equals(name.uname)) {
                    JOptionPane.showMessageDialog(this, "You cannot join your own event.", "Access Denied", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Parse date and time information from the event
                String eventDateStr = (String) event.get("date");
                String startTimeStr = (String) event.get("startTime");
                String endTimeStr = (String) event.get("endTime");

                DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");

                LocalDate eventDate = LocalDate.parse(eventDateStr, dateFormatter);
                LocalTime startTime = LocalTime.parse(startTimeStr, timeFormatter);
                LocalTime endTime = LocalTime.parse(endTimeStr, timeFormatter);

                LocalDateTime eventStart = LocalDateTime.of(eventDate, startTime);
                LocalDateTime eventEnd = LocalDateTime.of(eventDate, endTime);

                // Check if the event is ongoing
                if (now.isBefore(eventStart)) {
                    JOptionPane.showMessageDialog(this, "This event hasn't started yet.", "Too Early", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                if (now.isAfter(eventEnd)) {
                    JOptionPane.showMessageDialog(this, "This event has already ended.", "Too Late", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Check if the user already joined this specific event
                JSONArray attendanceArray = (JSONArray) event.getOrDefault("attendance", new JSONArray());
                for (Object o : attendanceArray) {
                    if (o instanceof JSONObject obj && name.uname.equals(obj.get("username"))) {
                        JOptionPane.showMessageDialog(this, "You have already joined this event.", "Already Recorded", JOptionPane.INFORMATION_MESSAGE);
                        return;
                    }
                }

                // Create a new attendance record
                JSONObject newAttendee = new JSONObject();
                newAttendee.put("username", name.uname);

                // Format and record the current time as "time in"
                DateTimeFormatter fullTimeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
                String timeIn = now.toLocalTime().format(fullTimeFormatter);
                newAttendee.put("time in", timeIn);

                // Determine if the user is late
                boolean isLate = false;
                if (event.containsKey("lateMinutes") && event.get("lateMinutes") != null) {
                    try {
                        int lateMinutes = Integer.parseInt(event.get("lateMinutes").toString());
                        LocalDateTime lateThreshold = eventStart.plusMinutes(lateMinutes);
                        if (now.isAfter(lateThreshold)) {
                            newAttendee.put("status", "Late");
                            isLate = true;
                        } else {
                            newAttendee.put("status", "On Time");
                        }
                    } catch (Exception e) {
                        // If there's a problem with lateMinutes, mark as 'On Time'
                        newAttendee.put("status", "On Time");
                    }
                } else {
                    // If lateMinutes is missing or null, default to 'On Time'
                    newAttendee.put("status", "On Time");
                }

                // Add the new attendee to the event and save
                attendanceArray.add(newAttendee);
                event.put("attendance", attendanceArray);
                list.set(i, event);
                save();

                matchfound++;

                // Notify user and launch dashboard
                JOptionPane.showMessageDialog(this,
                        isLate ? "You have been marked as LATE.\nYour attendance is still recorded." : "Your attendance is recorded.",
                        isLate ? "Late" : "Success",
                        isLate ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE);

                String selectedTitle = (String) event.get("title");
                ParticipantDashboard pd = new ParticipantDashboard(selectedTitle);
                pd.setEventTitle(selectedTitle);
                pd.setVisible(true);
                this.dispose(); // Close current window
                break;
            }

            // If no matching event was found
            if (matchfound == 0) {
                JOptionPane.showMessageDialog(this, "Invalid or expired code. Please try again.", "Code Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (IOException | ParseException ex) {
            // Log unexpected errors during the process
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "An error occurred. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Clear the code input field in all cases
            codeField.setText("");
        }
    }

    private void searchByEnter() {
        // Detect if the ENTER key has been pressed while the focus is on the text field
        int enter = Event.ENTER;

        if (enter == 10) { // 10 is the key code for Enter
            try {
                // Retrieve the search input from the text field and trim whitespace
                String searchText = SearchEvent.getText().trim();

                // Clear previous results from the table
                tablemodel.setRowCount(0);

                // Ensure the event data file is ready
                filecheck();

                // If the search input is empty, notify the user and cancel the search
                if (searchText.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Please enter something.", "No title", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                int matchfound = 0; // Track the number of matches found

                // Loop through each event and compare the title with the search input
                for (int i = 0; i < list.size(); i++) {
                    JSONObject jsonObject = (JSONObject) list.get(i);
                    String column1 = (String) jsonObject.get("title");
                    String column2 = (String) jsonObject.get("date");
                    String column3 = (String) jsonObject.get("startTime");
                    String column4 = (String) jsonObject.get("endTime");

                    // If the title contains the search input (case-insensitive), add it to the table
                    if (column1.toLowerCase().contains(searchText.toLowerCase())) {
                        tablemodel.addRow(new Object[]{column1, column2, column3, column4});
                        matchfound++;
                    }
                }

                // If no matching events were found, inform the user
                if (matchfound == 0) {
                    JOptionPane.showMessageDialog(rootPane, "No events matched.", "No Events", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                // Handle any issues related to file operations
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                // Handle any issues related to parsing JSON data
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void search() {
        try {
            // Get the user's input and remove any leading/trailing spaces
            String searchText = SearchEvent.getText().trim();

            // Clear any previous search results from the table
            tablemodel.setRowCount(0);

            // load the JSON file containing events
            filecheck();

            // If no input is provided, alert the user and stop the search
            if (searchText.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Please enter something.", "No title", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int matchfound = 0; // Counter to track how many matches are found

            // Loop through the list of events and search for matching titles
            for (int i = 0; i < list.size(); i++) {
                JSONObject jsonObject = (JSONObject) list.get(i);
                String column1 = (String) jsonObject.get("title");
                String column2 = (String) jsonObject.get("date");
                String column3 = (String) jsonObject.get("startTime");
                String column4 = (String) jsonObject.get("endTime");

                // Check if the title contains the search text (case-insensitive)
                if (column1.toLowerCase().contains(searchText.toLowerCase())) {
                    // Display the matching event details in the table
                    tablemodel.addRow(new Object[]{column1, column2, column3, column4});
                    matchfound++;
                }
            }

            // Inform the user if no matching events were found
            if (matchfound == 0) {
                JOptionPane.showMessageDialog(rootPane, "No events matched.", "No Events", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (IOException ex) {
            // Handle issues related to file access
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            // Handle issues related to parsing the data
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JoinBTN2;
    private javax.swing.JButton Joinbtn;
    private javax.swing.JLabel LBLShowUser;
    public javax.swing.JButton SearchBTn;
    private javax.swing.JTextField SearchEvent;
    private javax.swing.JTextField codeField;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
